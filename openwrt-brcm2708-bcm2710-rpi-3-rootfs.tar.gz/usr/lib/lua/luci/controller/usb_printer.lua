require("luci.sys")
module("luci.controller.usb_printer",package.seeall)
function index()
if not nixio.fs.access("/etc/config/usb_printer")then
return
end
entry({"admin","nas"},firstchild(),"NAS",44).dependent=false
local e
e=entry({"admin","nas","usb_printer"},cbi("usb_printer"),_("USB Printer Server"),50)
end
