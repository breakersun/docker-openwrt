module("luci.statistics.i18n",package.seeall)
require("luci.util")
require("luci.i18n")
Instance=luci.util.class()
function Instance.__init__(e,t)
e.i18n=luci.i18n
e.graph=t
end
function Instance._subst(a,e,t)
e=e:gsub("%%H",a.graph.opts.host or"")
e=e:gsub("%%pn",t.plugin or"")
e=e:gsub("%%pi",t.pinst or"")
e=e:gsub("%%dt",t.dtype or"")
e=e:gsub("%%di",t.dinst or"")
e=e:gsub("%%ds",t.dsrc or"")
return e
end
function Instance.title(n,o,a,t,e,i)
local i=i or
"p=%s/pi=%s/dt=%s/di=%s"%{
o,
(a and#a>0)and a or"(nil)",
(t and#t>0)and t or"(nil)",
(e and#e>0)and e or"(nil)"
}
return n:_subst(i,{
plugin=o,
pinst=a,
dtype=t,
dinst=e
})
end
function Instance.label(i,n,o,e,t,a)
local a=a or
"dt=%s/di=%s"%{
(e and#e>0)and e or"(nil)",
(t and#t>0)and t or"(nil)"
}
return i:_subst(a,{
plugin=n,
pinst=o,
dtype=e,
dinst=t
})
end
function Instance.ds(t,e)
local a=e.title or
"dt=%s/di=%s/ds=%s"%{
(e.type and#e.type>0)and e.type or"(nil)",
(e.instance and#e.instance>0)and e.instance or"(nil)",
(e.ds and#e.ds>0)and e.ds or"(nil)"
}
return t:_subst(a,{
dtype=e.type,
dinst=e.instance,
dsrc=e.ds
}):gsub(":","\\:")
end
