module("luci.statistics.rrdtool",package.seeall)
require("luci.statistics.datatree")
require("luci.statistics.rrdtool.colors")
require("luci.statistics.i18n")
require("luci.model.uci")
require("luci.util")
require("luci.sys")
local o=require"nixio.fs"
Graph=luci.util.class()
function Graph.__init__(a,o,e)
e=e or{}
local t=luci.model.uci.cursor()
local t=t:get_all("luci_statistics")
e.timespan=o or t.rrdtool.default_timespan or 900
e.rrasingle=e.rrasingle or(t.collectd_rrdtool.RRASingle=="1")
e.rramax=e.rramax or(t.collectd_rrdtool.RRAMax=="1")
e.host=e.host or t.collectd.Hostname or luci.sys.hostname()
e.width=e.width or t.rrdtool.image_width or 400
e.rrdpath=e.rrdpath or t.collectd_rrdtool.DataDir or"/tmp/rrd"
e.imgpath=e.imgpath or t.rrdtool.image_path or"/tmp/rrdimg"
e.rrdpath=e.rrdpath:gsub("/$","")
e.imgpath=e.imgpath:gsub("/$","")
a.colors=luci.statistics.rrdtool.colors.Instance()
a.tree=luci.statistics.datatree.Instance(e.host)
a.i18n=luci.statistics.i18n.Instance(a)
a.args={
"-a","PNG",
"-s","NOW-"..e.timespan,
"-w",e.width
}
a.opts=e
end
function Graph._mkpath(i,e,t,o,a)
local e=i.opts.host.."/"..e
if type(t)=="string"and t:len()>0 then
e=e.."-"..t
end
e=e.."/"..o
if type(a)=="string"and a:len()>0 then
e=e.."-"..a
end
return e
end
function Graph.mkrrdpath(e,...)
return string.format("%s/%s.rrd",e.opts.rrdpath,e:_mkpath(...))
end
function Graph.mkpngpath(e,...)
return string.format("%s/%s.%i.png",e.opts.imgpath,e:_mkpath(...),e.opts.timespan)
end
function Graph.strippngpath(t,e)
return e:sub(t.opts.imgpath:len()+2)
end
function Graph._forcelol(t,e)
if type(e[1])~="table"then
return({e})
end
return(e)
end
function Graph._rrdtool(i,e,a)
local t=e[1]:gsub("/[^/]+$","")
o.mkdirr(t)
local t={"rrdtool","graph"}
for a,t in ipairs(i.args)do
table.insert(e,1+a,t)
end
for o,e in ipairs(e)do
e=e..""
if a then
e=e:gsub("{file}",a)
end
t[#t+1]=luci.util.shellquote(e)
end
local e=io.popen(table.concat(t," "))
e:close()
end
function Graph._generic(o,t,s,h,r,y)
local f={}
local e={}
local a={}
local l={}
local u={}
local c=0
local w=false
local i=table.insert
local d=string.format
function _tif(t,e,...)
table.insert(t,string.format(e,...))
end
function __def(i)
local t=i.sname
local n=i.rrd
local a=i.ds
if not a or a:len()==0 then a="value"end
_tif(e,"DEF:%s_avg_raw=%s:%s:AVERAGE",t,n,a)
_tif(e,"CDEF:%s_avg=%s_avg_raw,%s",t,t,i.transform_rpn)
if not o.opts.rrasingle then
_tif(e,"DEF:%s_min_raw=%s:%s:MIN",t,n,a)
_tif(e,"CDEF:%s_min=%s_min_raw,%s",t,t,i.transform_rpn)
_tif(e,"DEF:%s_max_raw=%s:%s:MAX",t,n,a)
_tif(e,"CDEF:%s_max=%s_max_raw,%s",t,t,i.transform_rpn)
end
_tif(e,"CDEF:%s_nnl=%s_avg,UN,0,%s_avg,IF",t,t,t)
end
function __cdef(t)
local a
if t.flip then
a=l[#l]
else
a=u[#u]
end
if not a or t.overlay then
if o.opts.rrasingle or not o.opts.rramax then
_tif(e,"CDEF:%s_stk=%s_nnl",t.sname,t.sname)
_tif(e,"CDEF:%s_plot=%s_avg",t.sname,t.sname)
else
_tif(e,"CDEF:%s_stk=%s_nnl",t.sname,t.sname)
_tif(e,"CDEF:%s_plot=%s_max",t.sname,t.sname)
end
else
if o.opts.rrasingle or not o.opts.rramax then
_tif(e,"CDEF:%s_stk=%s_nnl,%s_stk,+",t.sname,t.sname,a)
_tif(e,"CDEF:%s_plot=%s_avg,%s_stk,+",t.sname,t.sname,a)
else
_tif(e,"CDEF:%s_stk=%s_nnl,%s_stk,+",t.sname,t.sname,a)
_tif(e,"CDEF:%s_plot=%s_max,%s_stk,+",t.sname,t.sname,a)
end
end
if t.flip then
_tif(e,"CDEF:%s_neg=%s_plot,-1,*",t.sname,t.sname)
if not t.overlay then
i(l,t.sname)
end
elseif not t.overlay then
i(u,t.sname)
end
if t.total then
_tif(e,
"CDEF:%s_avg_sample=%s_avg,UN,0,%s_avg,IF,sample_len,*",
t.sname,t.sname,t.sname
)
_tif(e,
"CDEF:%s_avg_sum=PREV,UN,0,PREV,IF,%s_avg_sample,+",
t.sname,t.sname,t.sname
)
end
end
function __cdef_totals()
if w then
_tif(e,"CDEF:mytime=%s_avg,TIME,TIME,IF",a[1].sname)
i(e,"CDEF:sample_len_raw=mytime,PREV(mytime),-")
i(e,"CDEF:sample_len=sample_len_raw,UN,0,sample_len_raw,IF")
end
end
function __line(a)
local n
local i
local h
local s
if type(a.color)=="string"then
n=a.color
i=o.colors:from_string(n)
elseif type(t.colors[a.name:gsub("[^%w]","_")])=="string"then
n=t.colors[a.name:gsub("[^%w]","_")]
i=o.colors:from_string(n)
else
i=o.colors:random()
n=o.colors:to_string(i)
end
i=o.colors:to_string(o.colors:faded(i))
if a.flip then
s="neg"
else
s="plot"
end
h=d("%-"..c.."s",a.title)
if not a.noarea then
_tif(e,"AREA:%s_%s#%s",a.sname,s,i)
end
_tif(e,"LINE%d:%s_%s#%s:%s",
a.width or(a.noarea and 2 or 1),
a.sname,s,n,h)
end
function __gprint(a)
local i=t.number_format or"%6.1lf"
local t=t.totals_format or"%5.1lf%s"
if not o.opts.rrasingle then
_tif(e,"GPRINT:%s_min:MIN:\tMin\\: %s",a.sname,i)
end
_tif(e,"GPRINT:%s_avg:AVERAGE:\tAvg\\: %s",a.sname,i)
if not o.opts.rrasingle then
_tif(e,"GPRINT:%s_max:MAX:\tMax\\: %s",a.sname,i)
end
if a.total then
_tif(e,"GPRINT:%s_avg_sum:LAST:(ca. %s Total)\\l",a.sname,t)
else
_tif(e,"GPRINT:%s_avg:LAST:\tLast\\: %s\\l",a.sname,i)
end
end
local n
if r then
n={r}
else
n=t.data.types or{}
end
if not(r or t.data.types)then
if t.data.instances then
for e,t in pairs(t.data.instances)do
i(n,e)
end
elseif t.data.sources then
for e,t in pairs(t.data.sources)do
i(n,e)
end
end
end
for n,e in ipairs(n)do
local n
if not t.per_instance then
if type(t.data.instances)=="table"and type(t.data.instances[e])=="table"then
n=t.data.instances[e]
else
n=o.tree:data_instances(s,h,e)
end
end
if type(n)~="table"or#n==0 then n={""}end
for n,d in ipairs(n)do
local r=e
if d:len()>0 then
r=r.."_"..d
end
local n={"value"}
if type(t.data.sources)=="table"then
if type(t.data.sources[r])=="table"then
n=t.data.sources[r]
elseif type(t.data.sources[e])=="table"then
n=t.data.sources[e]
end
end
for n,l in ipairs(n)do
local m=e.."_"..d:gsub("[^%w]","_").."_"..l
local u=e.."__"..l
local n={}
if type(t.data.options)=="table"then
if type(t.data.options[m])=="table"then
n=t.data.options[m]
elseif type(t.data.options[u])=="table"then
n=t.data.options[u]
elseif type(t.data.options[r])=="table"then
n=t.data.options[r]
elseif type(t.data.options[e])=="table"then
n=t.data.options[e]
end
end
i(a,{
rrd=n.rrd or o:mkrrdpath(s,h,e,d),
color=n.color or o.colors:to_string(o.colors:random()),
flip=n.flip or false,
total=n.total or false,
overlay=n.overlay or false,
transform_rpn=n.transform_rpn or"0,+",
noarea=n.noarea or false,
title=n.title or nil,
weight=n.weight or nil,
ds=l,
type=e,
instance=d,
index=#a+1,
sname=(#a+1)..e
})
a[#a].title=o.i18n:ds(a[#a])
if a[#a].title:len()>c then
c=a[#a].title:len()
end
if a[#a].total then
w=true
end
end
end
end
local n={""}
if t.per_instance then
n=o.tree:data_instances(s,h,a[1].type)
end
for r,n in ipairs(n)do
i(e,"-t")
i(e,o.i18n:title(s,h,a[1].type,n,t.title))
i(e,"-v")
i(e,o.i18n:label(s,h,a[1].type,n,t.vlabel))
if t.y_max then
i(e,"-u")
i(e,t.y_max)
end
if t.y_min then
i(e,"-l")
i(e,t.y_min)
end
if t.units_exponent then
i(e,"-X")
i(e,t.units_exponent)
end
if t.alt_autoscale then
i(e,"-A")
end
if t.alt_autoscale_max then
i(e,"-M")
end
if t.rrdopts then
for a,t in ipairs(t.rrdopts)do i(e,t)end
end
table.sort(a,function(t,e)
local t=t.weight or t.index or 0
local e=e.weight or e.index or 0
return t<e
end)
for a,e in ipairs(a)do
if t.per_instance then
e.instance=n
e.rrd=o:mkrrdpath(s,h,e.type,n)
end
__def(e)
end
__cdef_totals()
for e,t in ipairs(a)do
__cdef(a[1+#a-e])
end
for t,e in ipairs(a)do
__line(e)
__gprint(e)
end
i(e,1,o:mkpngpath(s,h,y..n))
i(f,e)
e={}
u={}
l={}
end
return f
end
function Graph.render(t,o,s,n)
dtype_instances=dtype_instances or{""}
local i={}
local e="luci.statistics.rrdtool.definitions."..o
local e,a=pcall(require,e)
if e and a and type(a.rrdargs)=="function"then
local e={}
for a,i in ipairs(t:_forcelol(a.rrdargs(t,o,s,nil,n)))do
if not n or not i.detail then
e[a]={}
local o=t:_generic(i,o,s,nil,a)
for i,o in ipairs(o)do
e[a][i]=o[1]
t:_rrdtool(o)
end
end
end
for a=1,#e[1]do
for t=1,#e do
table.insert(i,e[t][a])
end
end
end
return i
end
