module("luci.statistics.datatree",package.seeall)
local e=require("luci.util")
local i=require("luci.sys")
local o=require("nixio.fs")
local t=require("luci.model.uci").cursor()
local t=t:get_all("luci_statistics")
Instance=e.class()
function Instance.__init__(e,a)
e._host=a or i.hostname()
e._libdir="/usr/lib/collectd"
e._rrddir="/tmp/rrd"
if t and t.collectd then
e._host=a or t.collectd.Hostname or i.hostname()
e._libdir=t.collectd.PluginDir or"/usr/lib/collectd"
end
if t and t.collectd_rrdtool then
e._rrddir=t.collectd_rrdtool.DataDir or"/tmp/rrd"
end
e._libdir=e._libdir:gsub("/$","")
e._rrddir=e._rrddir:gsub("/$","")
e._plugins={}
e:_scan()
end
function Instance._mkpath(e,t,a)
local e=e._rrddir.."/"..e._host
if type(t)=="string"and t:len()>0 then
e=e.."/"..t
if type(a)=="string"and a:len()>0 then
e=e.."-"..a
end
end
return e
end
function Instance._ls(e,...)
local t=o.dir(e:_mkpath(...))
if t then
local e={}
while true do
local t=t()
if not t then break end
e[#e+1]=t
end
return e
end
end
function Instance._notzero(t,e)
for e in pairs(e)do
return true
end
return false
end
function Instance._scan(e)
local t=e:_ls()
if not t then
return
end
for a,t in ipairs(t)do
if t~="."and t~=".."and
o.stat(e:_mkpath(t)).type=="dir"
then
local t=t:gsub("%-.+$","")
if not e._plugins[t]then
e._plugins[t]={}
end
end
end
for t,o in pairs(e._plugins)do
local a=e:_ls()
if type(a)=="table"then
for a,e in ipairs(a)do
if e:find(t.."%-")or e==t then
local a=""
if e~=t then
a=e:gsub(t.."%-","",1)
end
o[a]={}
end
end
end
for i,o in pairs(o)do
a=e:_ls(t,i)
if type(a)=="table"then
for t,e in ipairs(a)do
if e:find("%.rrd")then
e=e:gsub("%.rrd","")
local t
local a
if e:find("%-")then
t=e:gsub("%-.+","")
a=e:gsub("[^%-]-%-","",1)
else
t=e
a=""
end
if not o[t]then
o[t]={a}
else
table.insert(o[t],a)
end
end
end
end
end
end
end
function Instance.plugins(e)
local t={}
for a,o in pairs(e._plugins)do
if e:_notzero(o)then
table.insert(t,a)
end
end
return t
end
function Instance.plugin_instances(t,a)
local e={}
for t,a in pairs(t._plugins[a])do
table.insert(e,t)
end
return e
end
function Instance.data_types(o,e,a)
local t={}
local e=o._plugins[e]
if type(e)=="table"and type(e[a])=="table"then
for e,a in pairs(e[a])do
table.insert(t,e)
end
end
return t
end
function Instance.data_instances(i,e,t,a)
local o={}
local e=i._plugins[e]
if type(e)=="table"and type(e[t])=="table"and type(e[t][a])=="table"then
for t,e in ipairs(e[t][a])do
table.insert(o,e)
end
end
return o
end
function Instance.host_instances(e)
local t=o.glob(e._rrddir..'/*')
local e={}
if t then
local a
for t in t do
e[#e+1]=o.basename(t)
end
end
return e
end
