module("luci.statistics.rrdtool.definitions.apcups",package.seeall)
function rrdargs(t,a,o)
local i=require("luci.util")
local e={}
local s=t.tree:data_types(a,o)
local n={}
for i,e in ipairs(s)do
n[e]=t.tree:data_instances(a,o,e)
end
local function h(e)
for t,e in pairs(e)do
if type(e)then return false end
end
return true
end
local function t(r,o)
local e=o['data']['instances']
if type(e)=="table"then
for t,a in pairs(e)do
if i.contains(s,t)then
for e=#a,1,-1 do
if not i.contains(n[t],a[e])then
table.remove(a,e)
end
end
if#a==0 then
e[t]=nil
end
else
e[t]=nil
end
end
if h(e)then return end
end
table.insert(r,o)
end
local a={
title="%H: Voltages on APC UPS - Battery",
vlabel="Volts DC",
alt_autoscale=true,
number_format="%5.1lfV",
data={
instances={
voltage={"battery"}
},
options={
voltage={title="Battery voltage",noarea=true}
}
}
}
t(e,a)
local a={
title="%H: Voltages on APC UPS - AC",
vlabel="Volts AC",
alt_autoscale=true,
number_format="%5.1lfV",
data={
instances={
voltage={"input","output"}
},
options={
voltage_output={color="00e000",title="Output voltage",noarea=true,overlay=true},
voltage_input={color="ffb000",title="Input voltage",noarea=true,overlay=true}
}
}
}
t(e,a)
local a={
title="%H: Load on APC UPS ",
vlabel="Percent",
y_min="0",
y_max="100",
number_format="%5.1lf%%",
data={
instances={
percent={"load"}
},
options={
percent_load={color="00ff00",title="Load level"}
}
}
}
t(e,a)
local a={
title="%H: Battery charge on APC UPS ",
vlabel="Percent",
y_min="0",
y_max="100",
number_format="%5.1lf%%",
data={
instances={
charge={""}
},
options={
charge={color="00ff0b",title="Charge level"}
}
}
}
t(e,a)
local a={
title="%H: Battery temperature on APC UPS ",
vlabel="\176C",
number_format="%5.1lf\176C",
data={
instances={
temperature={""}
},
options={
temperature={color="ffb000",title="Battery temperature"}}
}
}
t(e,a)
local a={
title="%H: Time left on APC UPS ",
vlabel="Minutes",
number_format="%.1lfm",
data={
instances={
timeleft={""}
},
options={
timeleft={color="0000ff",title="Time left"}
}
}
}
t(e,a)
local a={
title="%H: Incoming line frequency on APC UPS ",
vlabel="Hz",
number_format="%5.0lfhz",
data={
instances={
frequency={"input"}
},
options={
frequency_input={color="000fff",title="Line frequency"}
}
}
}
t(e,a)
return e
end
