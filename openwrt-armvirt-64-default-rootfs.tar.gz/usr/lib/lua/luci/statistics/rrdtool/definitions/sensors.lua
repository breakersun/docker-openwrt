module("luci.statistics.rrdtool.definitions.sensors",package.seeall)
function rrdargs(e,e,e)
return{
{
per_instance=true,
title="%H: %pi - %di",
vlabel="\176C",
number_format="%4.1lf\176C",
data={
types={"temperature"},
options={
temperature__value={
color="ff0000",
title="Temperature"
}
}
}
}
}
end
