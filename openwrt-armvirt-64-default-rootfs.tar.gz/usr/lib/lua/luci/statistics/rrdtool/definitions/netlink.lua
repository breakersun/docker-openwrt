module("luci.statistics.rrdtool.definitions.netlink",package.seeall)
function rrdargs(e,e,e)
local i={
title="%H: Netlink - Transfer on %pi",
vlabel="Bytes/s",
data={
sources={
if_octets={"tx","rx"}
},
options={
if_octets__tx={
title="Bytes (TX)",
total=true,
color="00ff00"
},
if_octets__rx={
title="Bytes (RX)",
flip=true,
total=true,
color="0000ff"
}
}
}
}
local t={
title="%H: Netlink - Packets on %pi",
vlabel="Packets/s",detail=true,
data={
types={"if_packets","if_dropped","if_errors"},
sources={
if_packets={"tx","rx"},
if_dropped={"tx","rx"},
if_errors={"tx","rx"}
},
options={
if_packets__tx={
weight=2,
title="Total   (TX)",
overlay=true,
total=true,
color="00ff00"
},
if_packets__rx={
weight=3,
title="Total   (RX)",
overlay=true,
flip=true,
total=true,
color="0000ff"
},
if_dropped__tx={
weight=1,
title="Dropped (TX)",
overlay=true,
total=true,
color="660055"
},
if_dropped__rx={
weight=4,
title="Dropped (RX)",
overlay=true,
flip=true,
total=true,
color="ff00ff"
},
if_errors__tx={
weight=0,
title="Errors  (TX)",
overlay=true,
total=true,
color="ff5500"
},
if_errors__rx={
weight=5,
title="Errors  (RX)",
overlay=true,
flip=true,
total=true,
color="ff0000"
}
}
}
}
local a={
title="%H: Netlink - Multicast on %pi",
vlabel="Packets/s",detail=true,
data={
types={"if_multicast"},
options={
if_multicast={
title="Packets",
total=true,
color="0000ff"
}
}
}
}
local o={
title="%H: Netlink - Collisions on %pi",
vlabel="Collisions/s",detail=true,
data={
types={"if_collisions"},
options={
if_collisions={
title="Collisions",
total=true,
color="ff0000"
}
}
}
}
local e={
title="%H: Netlink - Errors on %pi",
vlabel="Errors/s",detail=true,
data={
types={"if_tx_errors","if_rx_errors"},
instances={
if_tx_errors={"aborted","carrier","fifo","heartbeat","window"},
if_rx_errors={"length","missed","over","crc","fifo","frame"}
},
options={
if_tx_errors_aborted_value={total=true,color="ffff00",title="Aborted   (TX)"},
if_tx_errors_carrier_value={total=true,color="ffcc00",title="Carrier   (TX)"},
if_tx_errors_fifo_value={total=true,color="ff9900",title="Fifo      (TX)"},
if_tx_errors_heartbeat_value={total=true,color="ff6600",title="Heartbeat (TX)"},
if_tx_errors_window_value={total=true,color="ff3300",title="Window    (TX)"},
if_rx_errors_length_value={flip=true,total=true,color="ff0000",title="Length    (RX)"},
if_rx_errors_missed_value={flip=true,total=true,color="ff0033",title="Missed    (RX)"},
if_rx_errors_over_value={flip=true,total=true,color="ff0066",title="Over      (RX)"},
if_rx_errors_crc_value={flip=true,total=true,color="ff0099",title="CRC       (RX)"},
if_rx_errors_fifo_value={flip=true,total=true,color="ff00cc",title="Fifo      (RX)"},
if_rx_errors_frame_value={flip=true,total=true,color="ff00ff",title="Frame     (RX)"}
}
}
}
return{i,t,a,o,e}
end
