module("luci.statistics.rrdtool.definitions.interface",package.seeall)
function rrdargs(e,e,e)
local t={
per_instance=true,
title="%H: Transfer on %pi",
vlabel="Bytes/s",
data={
sources={
if_octets={"tx","rx"}
},
options={
if_octets__tx={
total=true,
color="00ff00",
title="Bytes (TX)"
},
if_octets__rx={
flip=true,
total=true,
color="0000ff",
title="Bytes (RX)"
}
}
}
}
local e={
per_instance=true,
title="%H: Packets on %pi",
vlabel="Packets/s",
data={
types={"if_packets","if_errors"},
sources={
if_packets={"tx","rx"},
if_errors={"tx","rx"}
},
options={
if_packets__tx={
weight=1,
overlay=true,
total=true,
color="00ff00",
title="Processed (TX)"
},
if_packets__rx={
weight=2,
overlay=true,
flip=true,
total=true,
color="0000ff",
title="Processed (RX)"
},
if_errors__tx={
weight=0,
overlay=true,
total=true,
color="ff5500",
title="Errors    (TX)"
},
if_errors__rx={
weight=3,
overlay=true,
flip=true,
total=true,
color="ff0000",
title="Errors    (RX)"
}
}
}
}
return{t,e}
end
