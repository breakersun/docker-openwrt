module("luci.statistics.rrdtool.definitions.memory",package.seeall)
function rrdargs(e,e,e,e)
return{
title="%H: Memory usage",
vlabel="MB",
number_format="%5.1lf%s",
y_min="0",
alt_autoscale_max=true,
data={
instances={
memory={"free","buffered","cached","used"}
},
options={
memory_buffered={color="0000ff",title="Buffered"},
memory_cached={color="ff00ff",title="Cached"},
memory_used={color="ff0000",title="Used"},
memory_free={color="00ff00",title="Free"}
}
}
}
end
