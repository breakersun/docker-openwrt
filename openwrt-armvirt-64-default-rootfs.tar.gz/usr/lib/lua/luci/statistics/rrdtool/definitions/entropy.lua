module("luci.statistics.rrdtool.definitions.entropy",package.seeall)
function rrdargs(e,e,e,e)
return{
title="%H: Available entropy",
vlabel="bits",
number_format="%4.0lf",
data={
types={"entropy"},
options={entropy={title="Entropy %di"}}
}
}
end
