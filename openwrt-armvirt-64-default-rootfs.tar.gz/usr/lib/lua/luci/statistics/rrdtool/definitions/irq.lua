module("luci.statistics.rrdtool.definitions.irq",package.seeall)
function rrdargs(e,e,e,e)
return{
title="%H: Interrupts",vlabel="Issues/s",
number_format="%5.0lf",data={
types={"irq"},
options={
irq={title="IRQ %di",noarea=true}
}
}
}
end
