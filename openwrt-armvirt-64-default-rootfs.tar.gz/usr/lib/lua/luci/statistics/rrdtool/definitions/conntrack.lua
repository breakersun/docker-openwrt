module("luci.statistics.rrdtool.definitions.conntrack",package.seeall)
function rrdargs(e,e,e,e)
return{
title="%H: Conntrack entries",
vlabel="Count",
number_format="%5.0lf",
data={
instances={
conntrack={""}
},
sources={
conntrack={"value"}
},
options={
conntrack={
color="0000ff",
title="Tracked connections"
}
}
}
}
end
