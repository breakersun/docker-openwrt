module("luci.statistics.rrdtool.definitions.olsrd",package.seeall)
function rrdargs(a,t,o,e)
local e={}
if o=="routes"then
e[#e+1]={
title="%H: Total amount of OLSR routes",vlabel="n",
number_format="%5.0lf",data={
types={"routes"},
options={
routes={
color="ff0000",
title="Total number of routes"
}
}
}
}
e[#e+1]={
title="%H: Average route ETX",vlabel="ETX",detail=true,
number_format="%5.1lf",data={
instances={"average"},
types={"route_etx"},
options={
route_etx={
title="Average route ETX"
}
}
}
}
e[#e+1]={
title="%H: Average route metric",vlabel="metric",detail=true,
number_format="%5.1lf",data={
instances={"average"},
types={"route_metric"},
options={
route_metric={
title="Average route metric"
}
}
}
}
elseif o=="links"then
e[#e+1]={
title="%H: Total amount of OLSR neighbours",vlabel="n",
number_format="%5.0lf",data={
instances={""},
types={"links"},
options={
links={
color="00ff00",
title="Number of neighbours"
}
}
}
}
local t=a.tree:data_instances(t,o,"signal_quality")
table.sort(t)
local a
for a=1,#t,2 do
local n="signal_quality_%s_value"%t[a]:gsub("[^%w]+","_")
local i="signal_quality_%s_value"%t[a+1]:gsub("[^%w]+","_")
local o=t[a]:match("^[^%-]+%-([^%-]+)%-.+")
e[#e+1]={
title="%H: Signal Quality".." ("..(o or"avg")..")",vlabel="ETX",
number_format="%5.2lf",detail=true,
data={
types={"signal_quality"},
instances={
signal_quality={t[a],t[a+1]},
},
options={
[n]={
color="00ff00",
title="LQ (%s)"%(o or"avg"),
},
[i]={
color="0000ff",
title="NLQ (%s)"%(o or"avg"),
flip=true
}
}
}
}
end
elseif o=="topology"then
e[#e+1]={
title="%H: Total amount of OLSR links",vlabel="n",
number_format="%5.0lf",data={
instances={""},
types={"links"},
options={
links={
color="0000ff",
title="Total number of links"
}
}
}
}
e[#e+1]={
title="%H: Average signal quality",vlabel="n",
number_format="%5.2lf",detail=true,
data={
instances={"average"},
types={"signal_quality"},
options={
signal_quality={
color="0000ff",
title="Average signal quality"
}
}
}
}
end
return e
end
