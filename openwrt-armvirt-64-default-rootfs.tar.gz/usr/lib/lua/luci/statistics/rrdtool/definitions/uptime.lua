module("luci.statistics.rrdtool.definitions.uptime",package.seeall)
function rrdargs(e,e,e,e)
return{
title="%H: Uptime",vlabel="seconds",
number_format="%5.0lf%s",data={
types={"uptime"},
options={
uptime={title="Uptime %di",noarea=true}
}
}
}
end
