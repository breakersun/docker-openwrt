module("luci.controller.samba",package.seeall)
function index()
if not nixio.fs.access("/etc/config/samba")then
return
end
local e
e=entry({"admin","services","samba"},cbi("samba"),_("Network Shares"))
e.dependent=true
end
