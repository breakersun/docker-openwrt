module("luci.controller.v2ray_server",package.seeall)
local e=require"luci.http"
local t=require"luci.model.cbi.v2ray_server.api.v2ray"
function index()
if not nixio.fs.access("/etc/config/v2ray_server")then
return
end
entry({"admin","vpn"},firstchild(),"VPN",45).dependent=false
entry({"admin","vpn","v2ray_server"},cbi("v2ray_server/index"),_("V2ray Server"),3).dependent=true
entry({"admin","vpn","v2ray_server","config"},cbi("v2ray_server/config")).leaf=true
entry({"admin","vpn","v2ray_server","users_status"},call("v2ray_users_status")).leaf=true
entry({"admin","vpn","v2ray_server","check"},call("v2ray_check")).leaf=true
entry({"admin","vpn","v2ray_server","update"},call("v2ray_update")).leaf=true
end
local function o(t)
e.prepare_content("application/json")
e.write_json(t or{code=1})
end
function v2ray_users_status()
local e={}
e.index=luci.http.formvalue("index")
e.status=luci.sys.call("ps -w| grep -v grep | grep '/var/etc/v2ray_server/"..luci.http.formvalue("id").."' >/dev/null")==0
o(e)
end
function v2ray_check()
local e=t.to_check("")
o(e)
end
function v2ray_update()
local a=nil
local i=e.formvalue("task")
if i=="extract"then
a=t.to_extract(e.formvalue("file"),e.formvalue("subfix"))
elseif i=="move"then
a=t.to_move(e.formvalue("file"))
else
a=t.to_download(e.formvalue("url"))
end
o(a)
end