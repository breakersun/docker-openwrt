module("luci.controller.luci_statistics.luci_statistics",package.seeall)
function index()
require("nixio.fs")
require("luci.util")
require("luci.statistics.datatree")
function _entry(e,...)
local t=e[5]or e[4]
if nixio.fs.access("/usr/lib/collectd/"..t..".so")then
entry(e,...)
end
end
local a={
s_output=_("Output plugins"),
s_general=_("General plugins"),
s_network=_("Network plugins"),
apcups=_("APC UPS"),
conntrack=_("Conntrack"),
contextswitch=_("Context Switches"),
cpu=_("Processor"),
cpufreq=_("CPU Frequency"),
csv=_("CSV Output"),
df=_("Disk Space Usage"),
disk=_("Disk Usage"),
dns=_("DNS"),
email=_("Email"),
entropy=_("Entropy"),
exec=_("Exec"),
interface=_("Interfaces"),
iptables=_("Firewall"),
irq=_("Interrupts"),
iwinfo=_("Wireless"),
load=_("System Load"),
memory=_("Memory"),
netlink=_("Netlink"),
network=_("Network"),
nut=_("UPS"),
olsrd=_("OLSRd"),
openvpn=_("OpenVPN"),
ping=_("Ping"),
processes=_("Processes"),
rrdtool=_("RRDTool"),
sensors=_("Sensors"),
splash_leases=_("Splash Leases"),
tcpconns=_("TCP Connections"),
thermal=_("Thermal"),
unixsock=_("UnixSock"),
uptime=_("Uptime")
}
local e={
output={"csv","network","rrdtool","unixsock"},
general={"apcups","contextswitch","cpu","cpufreq","df",
"disk","email","entropy","exec","irq","load","memory",
"nut","processes","sensors","thermal","uptime"},
network={"conntrack","dns","interface","iptables",
"netlink","olsrd","openvpn","ping",
"splash_leases","tcpconns","iwinfo"}
}
local t=entry({"admin","statistics"},template("admin_statistics/index"),_("Statistics"),80)
t.index=true
entry({"admin","statistics","collectd"},cbi("luci_statistics/collectd"),_("Setup"),20).subindex=true
local t=1
for o,e in luci.util.kspairs(e)do
local i=entry(
{"admin","statistics","collectd",o},
firstchild(),a["s_"..o],t*10
)
i.index=true
for i,e in luci.util.vspairs(e)do
_entry(
{"admin","statistics","collectd",o,e},
cbi("luci_statistics/"..e),
a[e]or e,i*10
)
end
t=t+1
end
local e=entry({"admin","statistics","graph"},template("admin_statistics/index"),_("Graphs"),10)
e.setuser="nobody"
e.setgroup="nogroup"
local e=luci.http.formvalue(nil,true)
local i=e.timespan or nil
local t=e.host or nil
local o=luci.statistics.datatree.Instance(t)
local e,e,e
for s,e,n in luci.util.vspairs(o:plugins())do
local o=o:plugin_instances(e)
entry(
{"admin","statistics","graph",e},
call("statistics_render"),a[e],n
).query={timespan=i,host=t}
if#o>1 then
local a,a,a
for n,a,o in luci.util.vspairs(o)do
entry(
{"admin","statistics","graph",e,a},
call("statistics_render"),a,o
).query={timespan=i,host=t}
end
end
end
end
function statistics_render()
require("luci.statistics.rrdtool")
require("luci.template")
require("luci.model.uci")
local e=luci.http.formvalue()
local t=luci.dispatcher.context.request
local t=luci.dispatcher.context.path
local t=luci.model.uci.cursor()
local s=luci.util.split(t:get("luci_statistics","collectd_rrdtool","RRATimespans"),"%s+",nil,true)
local n=e.timespan or t:get("luci_statistics","rrdtool","default_timespan")or s[1]
local h=e.host or t:get("luci_statistics","collectd","Hostname")or luci.sys.hostname()
local t={host=e.host}
local t=luci.statistics.rrdtool.Graph(luci.util.parse_units(n),t)
local r=t.tree:host_instances()
local o=false
local a,a,a,a
if e.img then
local a=require"luci.ltn12"
local e=io.open(t.opts.imgpath.."/"..e.img:gsub("%.+","."),"r")
if e then
luci.http.prepare_content("image/png")
a.pump.all(a.source.file(e),luci.http.write)
end
return
end
local i,e
local a={}
for t,a in ipairs(luci.dispatcher.context.path)do
if luci.dispatcher.context.path[t]=="graph"then
i=luci.dispatcher.context.path[t+1]
e={luci.dispatcher.context.path[t+2]}
end
end
if#e==0 then
e=t.tree:plugin_instances(i)
o=(#e>1)
elseif e[1]=="-"then
e[1]=""
o=true
end
for n,e in luci.util.vspairs(e)do
for i,o in luci.util.vspairs(t:render(i,e,o))do
table.insert(a,t:strippngpath(o))
a[a[#a]]=e
end
end
luci.template.render("public_statistics/graph",{
images=a,
plugin=i,
timespans=s,
current_timespan=n,
hosts=r,
current_host=h,
is_index=o
})
end
