module("luci.controller.transmission",package.seeall)
function index()
if not nixio.fs.access("/etc/config/transmission")then
return
end
entry({"admin","nas"},firstchild(),"NAS",44).dependent=false
local e=entry({"admin","nas","transmission"},cbi("transmission"),_("Transmission"))
e.dependent=true
end
