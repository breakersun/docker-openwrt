module("luci.controller.privoxy",package.seeall)
local a=require"nixio"
local i=require"nixio.fs"
local l=require"luci.dispatcher"
local n=require"luci.http"
local e=require"luci.i18n"
local s=require"luci.model.ipkg"
local d=require"luci.model.uci"
local r=require"luci.util"
local h=require"luci.sys"
local t="privoxy"
local o="3.0.23"
local u=[[/usr/sbin/privoxy --version | awk {'print $3'}]]
local c="luci-app-privoxy"
local m="Privoxy WEB proxy"
local f="1.0.6-1"
function index()
entry({"admin","services","privoxy"},cbi("privoxy"),_("Privoxy WEB proxy"),59)
entry({"admin","services","privoxy","logview"},call("logread")).leaf=true
entry({"admin","services","privoxy","startstop"},post("startstop")).leaf=true
entry({"admin","services","privoxy","status"},call("get_pid")).leaf=true
end
function app_description()
return e.translate("Privoxy is a non-caching web proxy with advanced filtering "
.."capabilities for enhancing privacy, modifying web page data and HTTP headers, "
.."controlling access, and removing ads and other obnoxious Internet junk.")
..[[<br /><strong>]]
..e.translate("For help use link at the relevant option")
..[[</strong>]]
end
function app_title_main()
return[[<a href="javascript:alert(']]
..e.translate("Version Information")
..[[\n\n]]..c
..[[\n\t]]..e.translate("Version")..[[:\t]]..f
..[[\n\n]]..t..[[ ]]..e.translate("required")..[[:]]
..[[\n\t]]..e.translate("Version")..[[:\t]]
..o..[[ ]]..e.translate("or higher")
..[[\n\n]]..t..[[ ]]..e.translate("installed")..[[:]]
..[[\n\t]]..e.translate("Version")..[[:\t]]
..(service_version()or e.translate("NOT installed"))
..[[\n\n]]
..[[')">]]
..e.translate(m)
..[[</a>]]
end
function service_version()
local e=nil
s.list_installed(t,function(a,t,a)
if t and(#t>0)then e=t end
end
)
if not e or(#e==0)then
e=r.exec(u)
if#e==0 then e=nil end
end
return e
end
function service_ok()
return s.compare_versions((service_version()or"0"),">=",o)
end
function service_update()
local a=l.build_url("admin","system","packages")
if not service_version()then
return[[<h3><strong><br /><font color="red">&nbsp;&nbsp;&nbsp;&nbsp;]]
..e.translate("Software package '%s' is not installed."%t)
..[[</font><br /><br />&nbsp;&nbsp;&nbsp;&nbsp;]]
..e.translate("required")..[[: ]]..t..[[ ]]..o.." "..e.translate("or higher")
..[[<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;]]
..[[<a href="]]..a..[[">]]
..e.translate("Please install current version !")
..[[</a><br />&nbsp;</strong></h3>]]
else
return[[<h3><strong><br /><br /><font color="red">&nbsp;&nbsp;&nbsp;&nbsp;]]
..e.translate("Software package '%s' is outdated."%t)
..[[</font><br /><br />&nbsp;&nbsp;&nbsp;&nbsp;]]
..e.translate("installed")..": "..service_version()
..[[<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;]]
..e.translate("required")..": "..o.." "..e.translate("or higher")
..[[<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;]]
..[[<a href="]]..a..[[">]]
..e.translate("Please update to the current version!")
..[[</a><br /><br />&nbsp;</strong></h3>]]
end
end
function logread()
local e=d.cursor()
local a=e:get("privoxy","privoxy","logdir")or"/var/log"
local t=e:get("privoxy","privoxy","logfile")or"privoxy.log"
e:unload("privoxy")
local e=i.readfile(a.."/"..t)
if not e or#e==0 then
e="_nodata_"
end
n.write(e)
end
function startstop()
local e=get_pid(true)
if e>0 then
h.call("/etc/init.d/privoxy stop")
a.nanosleep(1)
if a.kill(e,0)then
a.kill(e,9)
end
e=0
else
h.call("/etc/init.d/privoxy start")
a.nanosleep(1)
e=tonumber(i.readfile("/var/run/privoxy.pid")or 0)
if e>0 and not a.kill(e,0)then
e=0
end
end
n.write(tostring(e))
end
function get_pid(t)
local e=tonumber(i.readfile("/var/run/privoxy.pid")or 0)
if e>0 and not a.kill(e,0)then
e=0
end
if t then
return e
else
n.write(tostring(e))
end
end
function value_parse(e,i,d)
local t=e:formvalue(i)
local r=(t and(#t>0))
local n=e:cfgvalue(i)
local h=(e.rmempty or e.optional)
local a
if type(t)=="table"and type(n)=="table"then
a=(#t==#n)
if a then
for e=1,#t do
if n[e]~=t[e]then
a=false
end
end
end
if a then
t=n
end
end
local o,s=e:validate(t)
if not o then
if d then
return
end
if r then
e:add_error(i,"invalid",s or e.title..": invalid")
return
elseif not h then
e:add_error(i,"missing",s or e.title..": missing")
return
elseif s then
e:add_error(i,"invalid",s)
return
end
end
a=(o==n)
local l=(o and(#o>0))and true or false
local d=(o==e.default)
if h and(not l or d)then
if e:remove(i)then
e.section.changed=true
end
return
end
if not e.forcewrite and a then
return
end
assert(o,"\n option: "..e.option..
"\n fvalue: "..tostring(t)..
"\n fexist: "..tostring(r)..
"\n cvalue: "..tostring(n)..
"\n vvalue: "..tostring(o)..
"\n vexist: "..tostring(l)..
"\n rm_opt: "..tostring(h)..
"\n eq_cfg: "..tostring(a)..
"\n eq_def: "..tostring(d)..
"\n errtxt: "..tostring(s))
if e:write(i,o)and not a then
e.section.changed=true
end
end
