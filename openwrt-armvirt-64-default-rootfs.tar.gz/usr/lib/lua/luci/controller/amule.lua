module("luci.controller.amule",package.seeall)
local t=luci.model.uci.cursor()
local i=t:get("amule","main","config_dir")
function index()
if not nixio.fs.access("/etc/config/amule")then
return
end
entry({"admin","nas"},firstchild(),"NAS",45).dependent=false
local e=entry({"admin","nas","amule"},cbi("amule"),_("aMule Settings"))
e.dependent=true
entry({"admin","nas","amule","logview"},call("logread")).leaf=true
entry({"admin","nas","amule","status"},call("get_pid")).leaf=true
entry({"admin","nas","amule","amulecmd"},call("amulecmd")).leaf=true
entry({"admin","nas","amule","startstop"},post("startstop")).leaf=true
entry({"admin","nas","amule","down_kad"},post("down_kad")).leaf=true
entry({"admin","nas","amule","down_ed2k"},post("down_ed2k")).leaf=true
end
function logread()
local e=luci.model.uci.cursor()
local t=e:get("amule","main","config_dir")or"/var/run/amule"
e:unload("amule")
local e=nixio.fs.readfile(t.."/logfile")
if not e or#e==0 then
e="_nodata_"
end
luci.http.write(e)
end
function startstop()
local e=get_pid(true)
if e>0 then
luci.sys.call("/etc/init.d/amule stop")
nixio.nanosleep(1)
if nixio.kill(e,0)then
nixio.kill(e,9)
end
e=0
else
luci.sys.call("/etc/init.d/amule start")
nixio.nanosleep(1)
e=tonumber(luci.sys.exec("pidof amuled"))or 0
if e>0 and not nixio.kill(e,0)then
e=0
end
end
luci.http.write(tostring(e))
end
function down_kad()
url=t:get("amule","main","kad_nodes_url")
data_path=i.."/nodes.dat"
proto=string.gsub(url,"://%S*","")
proto_opt=(proto=="https")and" --no-check-certificate"or""
cmd="wget -O /tmp/down_nodes.dat \""..url.."\""..proto_opt..
" && cat /tmp/down_nodes.dat > ".."\""..data_path.."\""
luci.sys.call(cmd)
end
function down_ed2k()
url=t:get("amule","main","ed2k_servers_url")
data_path=i.."/server.met"
proto=string.gsub(url,"://%S*","")
proto_opt=(proto=="https")and" --no-check-certificate"or""
cmd="wget -O /tmp/down_server.met \""..url.."\""..proto_opt..
" && cat /tmp/down_server.met > ".."\""..data_path.."\""
luci.sys.call(cmd)
end
function get_pid(i)
local e=tonumber(luci.sys.exec("pidof amuled"))or 0
local o=false
if e>0 and not nixio.kill(e,0)then
e=0
end
if e>0 then
o=true
else
o=false
end
local t=tonumber(luci.sys.exec("pidof amuleweb"))or 0
local a=false
if t>0 and not nixio.kill(t,0)then
t=0
end
if t>0 then
a=true
else
a=false
end
local t={
amuled=o,
amuled_pid=e,
amuleweb=a
}
if i then
return e
else
luci.http.prepare_content("application/json")
luci.http.write_json(t)
end
end
function amulecmd()
local e=""
local t={}
local a=luci.http.formvalue("cmd")
local a="HOME=\""..i.."\" /usr/bin/amulecmd".." -c \""..a.."\" 2>&1"
local a=io.popen(a,"rw")
e=a:read("*a")
a:close()
if not e then
e=""
end
e=string.gsub(e,"This is amulecmd %S*\n","")
e=string.gsub(e,"Creating client%S*\n","")
e=string.gsub(e,"Succeeded! Connection established to aMule %S*\n","")
e=string.gsub(e,"\n","\r\n")
t[#t+1]=e
if#t>0 then
luci.http.prepare_content("application/json")
luci.http.write_json(t)
return
end
luci.http.status(404,"No such device")
end
