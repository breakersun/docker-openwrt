local e=require"nixio.fs"
local o=require"luci.dispatcher"
local l=require"luci.http"
local i=require"luci.sys"
local n=require"luci.controller.ddns"
local t=require"luci.tools.ddns"
local r=not(t.has_ipv6
and t.has_ssl
and t.has_proxy
and t.has_bindhost
and t.has_forceip
and t.has_dnsserver
and t.has_bindnet
and t.has_cacerts
)
local h=not i.init.enabled("ddns")
local d=not n.service_ok()
font_red=[[<font color="red">]]
font_off=[[</font>]]
bold_on=[[<strong>]]
bold_off=[[</strong>]]
m=Map("ddns")
m.title=n.app_title_main()
m.description=n.app_description()
m.on_after_commit=function(e)
if e.changed then
local e=n.luci_helper
if i.init.enabled("ddns")then
e=e.." -- restart"
os.execute(e)
else
e=e.." -- reload"
os.execute(e)
end
end
end
a=m:section(SimpleSection)
a.template="ddns/overview_status"
if r or d or h then
s=m:section(SimpleSection,translate("Hints"))
if d then
local e=s:option(DummyValue,"_update_needed")
e.titleref=o.build_url("admin","system","packages")
e.rawhtml=true
e.title=font_red..bold_on..
translate("Software update required")..bold_off..font_off
e.value=translate("The currently installed 'ddns-scripts' package did not support all available settings.")..
"<br />"..
translate("Please update to the current version!")
end
if h then
local e=s:option(DummyValue,"_not_enabled")
e.titleref=o.build_url("admin","system","startup")
e.rawhtml=true
e.title=bold_on..
translate("DDNS Autostart disabled")..bold_off
e.value=translate("Currently DDNS updates are not started at boot or on interface events.".."<br />"..
"You can start/stop each configuration here. It will run until next reboot.")
end
if r then
local e=s:option(DummyValue,"_separate")
e.titleref=o.build_url("admin","services","ddns","hints")
e.rawhtml=true
e.title=bold_on..
translate("Show more")..bold_off
e.value=translate("Follow this link".."<br />"..
"You will find more hints to optimize your system to run DDNS scripts with all options")
end
end
ts=m:section(TypedSection,"service",
translate("Overview"),
translate("Below is a list of configured DDNS configurations and their current state.")
.."<br />"
..translate("If you want to send updates for IPv4 and IPv6 you need to define two separate Configurations "
.."i.e. 'myddns_ipv4' and 'myddns_ipv6'")
.."<br />"
..[[<a href="]]..o.build_url("admin","services","ddns","global")..[[">]]
..translate("To change global settings click here")..[[</a>]])
ts.sectionhead=translate("Configuration")
ts.template="cbi/tblsection"
ts.addremove=true
ts.extedit=o.build_url("admin","services","ddns","detail","%s")
function ts.create(t,e)
AbstractSection.create(t,e)
l.redirect(t.extedit:format(e))
end
dom=ts:option(DummyValue,"_lookupIP",
translate("Lookup Hostname").."<br />"..translate("Registered IP"))
dom.template="ddns/overview_doubleline"
function dom.set_one(e,t)
local e=e.map:get(t,"lookup_host")or""
if e~=""then
return e
else
return[[<em>]]..translate("config error")..[[</em>]]
end
end
function dom.set_two(e,a)
local o=t.calc_seconds(
tonumber(e.map:get(a,"check_interval"))or 10,
e.map:get(a,"check_unit")or"minutes")
local t=t.get_regip(a,o)
if t=="NOFILE"then
local s=e.map:get(a,"lookup_host")or""
if s==""then return""end
local o=e.map:get(a,"dnsserver")or""
local h=tonumber(e.map:get(a,"use_ipv6")or 0)
local l=tonumber(e.map:get(a,"force_ipversion")or 0)
local d=tonumber(e.map:get(a,"force_dnstcp")or 0)
local r=tonumber(e.map:get(a,"is_glue")or 0)
local e=n.luci_helper..[[ -]]
if(h==1)then e=e..[[6]]end
if(l==1)then e=e..[[f]]end
if(d==1)then e=e..[[t]]end
if(r==1)then e=e..[[g]]end
e=e..[[l ]]..s
e=e..[[ -S ]]..a
if(#o>0)then e=e..[[ -d ]]..o end
e=e..[[ -- get_registered_ip]]
t=i.exec(e)
end
if t==""then t=translate("no data")end
return t
end
ena=ts:option(Flag,"enabled",
translate("Enabled"))
ena.template="ddns/overview_enabled"
ena.rmempty=false
upd=ts:option(DummyValue,"_update",
translate("Last Update").."<br />"..translate("Next Update"))
upd.template="ddns/overview_doubleline"
function upd.set_one(a,e)
local a=i.uptime()
local e=t.get_lastupd(e)
if e>a then
e=0
end
if e==0 then
return translate("never")
else
local e=os.time()-a+e
return t.epoch2date(e)
end
end
function upd.set_two(o,e)
local s=tonumber(o.map:get(e,"enabled")or 0)
local a=translate("unknown error")
local n=tonumber(o.map:get(e,"force_interval")or 72)
local o=o.map:get(e,"force_unit")or"hours"
local n=t.calc_seconds(n,o)
local i=i.uptime()
local o=t.get_lastupd(e)
if o>i then
o=0
end
local e=t.get_pid(e)
if o>0 then
local e=os.time()-i+o+n
datelast=t.epoch2date(e)
end
if e>0 and(o+n-i)<0 then
a=translate("Verify")
elseif n==0 then
a=translate("Run once")
elseif e==0 and s==0 then
a=translate("Disabled")
elseif e==0 and s~=0 then
a=translate("Stopped")
end
return a
end
btn=ts:option(Button,"_startstop",
translate("Process ID").."<br />"..translate("Start / Stop"))
btn.template="ddns/overview_startstop"
function btn.cfgvalue(o,a)
local e=t.get_pid(a)
if e>0 then
btn.inputtitle="PID: "..e
btn.inputstyle="reset"
btn.disabled=false
elseif(o.map:get(a,"enabled")or"0")~="0"then
btn.inputtitle=translate("Start")
btn.inputstyle="apply"
btn.disabled=false
else
btn.inputtitle="----------"
btn.inputstyle="button"
btn.disabled=true
end
return true
end
return m
