local e=require"nixio.fs"
local i=require"luci.sys"
local a=require"luci.model.uci".cursor()
local e=luci.sys.exec("ps --help 2>&1 | grep BusyBox")
local o=(string.len(e)>0)and"ps w"or"ps axfw"
local n=Map("openvpn",translate("OpenVPN"))
local e=n:section(TypedSection,"openvpn",translate("OpenVPN instances"),translate("Below is a list of configured OpenVPN instances and their current state"))
e.template="cbi/tblsection"
e.template_addremove="openvpn/cbi-select-input-add"
e.addremove=true
e.add_select_options={}
e.extedit=luci.dispatcher.build_url(
"admin","services","openvpn","basic","%s"
)
a:load("openvpn_recipes")
a:foreach("openvpn_recipes","openvpn_recipe",
function(t)
e.add_select_options[t['.name']]=
t['_description']or t['.name']
end
)
function e.getPID(e)
local e=i.exec("%s | grep -w '[o]penvpn(%s)'"%{o,e})
if e and#e>0 then
return tonumber(e:match("^%s*(%d+)"))
else
return nil
end
end
function e.parse(t,o)
local a=luci.http.formvalue(
luci.cbi.CREATE_PREFIX..t.config.."."..
t.sectiontype..".select"
)
if a and not e.add_select_options[a]then
t.invalid_cts=true
else
TypedSection.parse(t,o)
end
end
function e.create(o,t)
local i=luci.http.formvalue(
luci.cbi.CREATE_PREFIX..o.config.."."..
o.sectiontype..".select"
)
t=luci.http.formvalue(
luci.cbi.CREATE_PREFIX..o.config.."."..
o.sectiontype..".text"
)
if string.len(t)>3 and not t:match("[^a-zA-Z0-9_]")then
a:section(
"openvpn","openvpn",t,
a:get_all("openvpn_recipes",i)
)
a:delete("openvpn",t,"_role")
a:delete("openvpn",t,"_description")
a:save("openvpn")
luci.http.redirect(o.extedit:format(t))
else
o.invalid_cts=true
end
end
e:option(Flag,"enabled",translate("Enabled"))
local t=e:option(DummyValue,"_active",translate("Started"))
function t.cfgvalue(a,t)
local e=e.getPID(t)
if e~=nil then
return(i.process.signal(e,0))
and translatef("yes (%i)",e)
or translate("no")
end
return translate("no")
end
local t=e:option(Button,"_updown",translate("Start/Stop"))
t._state=false
t.redirect=luci.dispatcher.build_url(
"admin","services","openvpn"
)
function t.cbid(t,a)
local e=e.getPID(a)
t._state=e~=nil and i.process.signal(e,0)
t.option=t._state and"stop"or"start"
return AbstractValue.cbid(t,a)
end
function t.cfgvalue(e,t)
e.title=e._state and"stop"or"start"
e.inputstyle=e._state and"reset"or"reload"
end
function t.write(t,a,o)
if t.option=="stop"then
local e=e.getPID(a)
if e~=nil then
i.process.signal(e,15)
end
else
luci.sys.call("/etc/init.d/openvpn start %s"%a)
end
luci.http.redirect(t.redirect)
end
local t=e:option(DummyValue,"port",translate("Port"))
function t.cfgvalue(e,t)
local e=AbstractValue.cfgvalue(e,t)
return e or"1194"
end
local e=e:option(DummyValue,"proto",translate("Protocol"))
function e.cfgvalue(e,t)
local e=AbstractValue.cfgvalue(e,t)
return e or"udp"
end
return n
