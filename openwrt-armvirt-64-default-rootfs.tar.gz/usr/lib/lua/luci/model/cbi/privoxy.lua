local o=require"nixio.fs"
local d=require"luci.sys"
local c=require"luci.util"
local i=require"luci.dispatcher"
local l=require"luci.cbi.datatypes"
local a=require"luci.controller.privoxy"
local t=[[<a href="http://www.privoxy.org/user-manual/config.html#%s" target="_blank">%s</a>]]
if not a.service_ok()then
local e=SimpleForm("_sf")
e.title=a.app_title_main()
e.description=a.app_description()
e.embedded=true
e.submit=false
e.reset=false
local t=e:section(SimpleSection)
local t=t:option(DummyValue,"_dv")
t.titleref=i.build_url("admin","system","packages")
t.rawhtml=true
t.value=a.service_update()
return e
end
if not o.access("/etc/config/privoxy")then
o.writefile("/etc/config/privoxy","")
end
local r=Map("privoxy")
r.title=a.app_title_main()
r.description=a.app_description()
function r.commit_handler(e)
if e.changed then
os.execute("/etc/init.d/privoxy reload &")
end
end
local e=r:section(NamedSection,"privoxy","privoxy")
function e.cfgvalue(t,a)
if not t.map:get("system")then
t.map:set("system",nil,"system")
end
if not t.map:get(a)then
t.map:set(a,nil,t.sectiontype)
end
return t.map:get(a)
end
e:tab("sys",
translate("System"),
nil)
local function u(t,a)
return string.format(translate("System").." - %s: %s",t,a)
end
e:tab("doc",
translate("Documentation"),
translate("If you intend to operate Privoxy for more users than just yourself, "
.."it might be a good idea to let them know how to reach you, what you block "
.."and why you do that, your policies, etc."))
local function m(t,a)
return string.format(translate("Documentation").." - %s: %s",t,a)
end
e:tab("filter",
translate("Files and Directories"),
translate("Privoxy can (and normally does) use a number of other files "
.."for additional configuration, help and logging. This section of "
.."the configuration file tells Privoxy where to find those other files."))
local function s(t,a)
return string.format(translate("Files and Directories").." - %s: %s",t,a)
end
e:tab("access",
translate("Access Control"),
translate("This tab controls the security-relevant aspects of Privoxy's configuration."))
local function h(a,t)
return string.format(translate("Access Control").." - %s: %s",a,t)
end
e:tab("forward",
translate("Forwarding"),
translate("Configure here the routing of HTTP requests through a chain of multiple proxies. "
.."Note that parent proxies can severely decrease your privacy level. "
.."Also specified here are SOCKS proxies."))
e:tab("misc",
translate("Miscellaneous"),
nil)
local function i(a,t)
return string.format(translate("Miscellaneous").." - %s: %s",a.title_base,t)
end
e:tab("debug",
translate("Logging"),
nil)
e:tab("logview",
translate("Log File Viewer"),
nil)
local n=e:taboption("sys",Button,"_startstop")
n.title=translate("Start / Stop")
n.description=translate("Start/Stop Privoxy WEB Proxy")
n.template="privoxy/detail_startstop"
function n.cfgvalue(e,e)
local e=a.get_pid(true)
if e>0 then
n.inputtitle="PID: "..e
n.inputstyle="reset"
n.disabled=false
else
n.inputtitle=translate("Start")
n.inputstyle="apply"
n.disabled=false
end
return true
end
local n=e:taboption("sys",Flag,"_enabled")
n.title=translate("Enabled")
n.description=translate("Enable/Disable autostart of Privoxy on system startup and interface events")
n.orientation="horizontal"
n.rmempty=false
function n.cfgvalue(e,e)
return(d.init.enabled("privoxy"))and"1"or"0"
end
function n.write(t,t,e)
if e=="1"then
return d.init.enable("privoxy")
else
return d.init.disable("privoxy")
end
end
local n=e:taboption("sys",Value,"boot_delay")
n.title=translate("Boot delay")
n.description=translate("Delay (in seconds) during system boot before Privoxy start")
..[[<br />]]
..translate("During delay ifup-events are not monitored !")
n.default="10"
n.rmempty=false
function n.cfgvalue(e,t)
local e=tonumber(e.map:get("system","boot_delay"))
if not e then return nil end
return tostring(e)
end
function n.validate(t,a)
local e=tonumber(a)
if not e then
return nil,u(t.title,translate("Value is not a number"))
elseif e<0 or e>300 then
return nil,u(t.title,translate("Value not between 0 and 300"))
end
return a
end
function n.write(e,t,o)
local a=e:formvalue(t)
local t=e:cfgvalue(t)
if(a~=t)then
e.map:set("system","boot_delay",o)
end
end
local n=e:taboption("doc",Value,"hostname")
n.title=string.format(t,"HOSTNAME","Hostname")
n.description=translate("The hostname shown on the CGI pages.")
n.placeholder=d.hostname()
n.optional=true
n.rmempty=true
function n.parse(o,t,e)
a.value_parse(o,t,e)
end
local n=e:taboption("doc",Value,"user_manual")
n.title=string.format(t,"USER-MANUAL","User Manual")
n.description=translate("Location of the Privoxy User Manual.")
n.placeholder="http://www.privoxy.org/user-manual/"
n.optional=true
n.rmempty=true
function n.parse(e,t,o)
a.value_parse(e,t,o)
end
local n=e:taboption("doc",Value,"admin_address")
n.title_base="Admin Email"
n.title=string.format(t,"ADMIN-ADDRESS",n.title_base)
n.description=translate("An email address to reach the Privoxy administrator.")
n.placeholder="privoxy.admin@example.com"
n.optional=true
n.rmempty=true
function n.validate(t,e)
if not e or#e==0 then
return""
end
if not(e:match("[A-Za-z0-9%.%%%+%-]+@[A-Za-z0-9%.%%%+%-]+%.%w%w%w?%w?"))then
return nil,m(t.title_base,translate("Invalid email address"))
end
return e
end
function n.parse(o,t,e)
a.value_parse(o,t,e)
end
local n=e:taboption("doc",Value,"proxy_info_url")
n.title=string.format(t,"PROXY-INFO-URL","Proxy Info URL")
n.description=translate("A URL to documentation about the local Privoxy setup, configuration or policies.")
n.optional=true
n.rmempty=true
function n.parse(t,o,e)
a.value_parse(t,o,e)
end
local n=e:taboption("doc",Value,"trust_info_url")
n.title=string.format(t,"TRUST-INFO-URL","Trust Info URLs")
n.description=translate("A URL to be displayed in the error page that users will see if access to an untrusted page is denied.")
..[[<br /><strong>]]
..translate("The value of this option only matters if the experimental trust mechanism has been activated.")
..[[</strong>]]
n.optional=true
n.rmepty=true
function n.parse(o,e,t)
a.value_parse(o,e,t)
end
local n=e:taboption("filter",Value,"logdir")
n.title_base="Log Directory"
n.title=string.format(t,"LOGDIR",n.title_base)
n.description=translate("The directory where all logging takes place (i.e. where the logfile is located).")
..[[<br />]]
..translate("No trailing '/', please.")
n.default="/var/log"
n.rmempty=false
function n.validate(t,e)
if not e or#e==0 then
return nil,s(t.title_base,translate("Mandatory Input: No Directory given!"))
elseif not o.access(e)then
return nil,s(t.title_base,translate("Directory does not exist!"))
else
return e
end
end
function n.parse(e,t,o)
a.value_parse(e,t,o)
end
local a=e:taboption("filter",Value,"logfile")
a.title_base="Log File"
a.title=string.format(t,"LOGFILE",a.title_base)
a.description=translate("The log file to use. File name, relative to log directory.")
a.default="privoxy.log"
a.rmempty=false
function a.validate(t,e)
if not e or#e==0 then
return nil,s(t.title_base,translate("Mandatory Input: No File given!"))
else
return e
end
end
local a=e:taboption("filter",Value,"confdir")
a.title_base="Configuration Directory"
a.title=string.format(t,"CONFDIR",a.title_base)
a.description=translate("The directory where the other configuration files are located.")
..[[<br />]]
..translate("No trailing '/', please.")
a.default="/etc/privoxy"
a.rmempty=false
function a.validate(t,e)
if not e or#e==0 then
return nil,s(t.title_base,translate("Mandatory Input: No Directory given!"))
elseif not o.access(e)then
return nil,s(t.title_base,translate("Directory does not exist!"))
else
return e
end
end
local n=e:taboption("filter",Value,"templdir")
n.title_base="Template Directory"
n.title=string.format(t,"TEMPLDIR",n.title_base)
n.description=translate("An alternative directory where the templates are loaded from.")
..[[<br />]]
..translate("No trailing '/', please.")
n.placeholder="/etc/privoxy/templates"
n.rmempty=true
function n.validate(t,e)
if not o.access(e)then
return nil,s(t.title_base,translate("Directory does not exist!"))
else
return e
end
end
local n=e:taboption("filter",Value,"temporary_directory")
n.title_base="Temporary Directory"
n.title=string.format(t,"TEMPORARY-DIRECTORY",n.title_base)
n.description=translate("A directory where Privoxy can create temporary files.")
..[[<br /><strong>]]
..translate("Only when using 'external filters', Privoxy has to create temporary files.")
..[[</strong>]]
n.rmempty=true
local n=e:taboption("filter",DynamicList,"actionsfile")
n.title_base="Action Files"
n.title=string.format(t,"ACTIONSFILE",n.title_base)
n.description=translate("The actions file(s) to use. Multiple actionsfile lines are permitted, and are in fact recommended!")
..[[<br /><strong>match-all.action := </strong>]]
..translate("Actions that are applied to all sites and maybe overruled later on.")
..[[<br /><strong>default.action := </strong>]]
..translate("Main actions file")
..[[<br /><strong>user.action := </strong>]]
..translate("User customizations")
n.rmempty=false
function n.validate(r,t)
if not t or#t==0 then
return nil,h(r.title_base,translate("Mandatory Input: No files given!"))
end
local n=a:formvalue(e.section)
local a=false
local i=""
if type(t)=="table"then
local e
for t,e in ipairs(t)do
if e and#e>0 then
if not o.access(n.."/"..e)then
a=true
i=e
break
end
end
end
else
if not o.access(n.."/"..t)then
a=true
i=t
end
end
if a then
return nil,string.format(s(r.title_base,translate("File '%s' not found inside Configuration Directory")),i)
end
return t
end
local n=e:taboption("filter",DynamicList,"filterfile")
n.title_base="Filter files"
n.title=string.format(t,"FILTERFILE",n.title_base)
n.description=translate("The filter files contain content modification rules that use regular expressions.")
n.rmempty=false
function n.validate(n,t)
if not t or#t==0 then
return nil,h(n.title_base,translate("Mandatory Input: No files given!"))
end
local h=a:formvalue(e.section)
local a=false
local i=""
if type(t)=="table"then
local e
for t,e in ipairs(t)do
if e and#e>0 then
if not o.access(h.."/"..e)then
a=true
i=e
break
end
end
end
else
if not o.access(h.."/"..t)then
a=true
i=t
end
end
if a then
return nil,string.format(s(n.title_base,translate("File '%s' not found inside Configuration Directory")),i)
end
return t
end
local n=e:taboption("filter",Value,"trustfile")
n.title_base="Trust file"
n.title=string.format(t,"TRUSTFILE",n.title_base)
n.description=translate("The trust mechanism is an experimental feature for building white-lists "
.."and should be used with care.")
..[[<br /><strong>]]
..translate("It is NOT recommended for the casual user.")
..[[</strong>]]
n.placeholder="user.trust"
n.rmempty=true
function n.validate(h,t)
local n=a:formvalue(e.section)
local i=false
local a=""
if type(t)=="table"then
local e
for t,e in ipairs(t)do
if e and#e>0 then
if not NCFS.access(n.."/"..e)then
i=true
a=e
break
end
end
end
else
if not o.access(n.."/"..t)then
i=true
a=t
end
end
if i then
return nil,string.format(s(h.title_base,translate("File '%s' not found inside Configuration Directory")),a)
end
return t
end
local a=e:taboption("access",DynamicList,"listen_address")
a.title_base="Listen addresses"
a.title=string.format(t,"LISTEN-ADDRESS",a.title_base)
a.description=translate("The address and TCP port on which Privoxy will listen for client requests.")
..[[<br />]]
..translate("Syntax: ")
.."IPv4:Port / [IPv6]:Port / Host:Port"
a.default="127.0.0.1:8118"
a.rmempty=false
function a.validate(i,t)
if not t or#t==0 then
return nil,h(i.title_base,translate("Mandatory Input: No Data given!"))
end
local function o(a)
local e=c.split(a,"]:")
local t
if e[2]then
t=string.gsub(e[1],"%[","")
if not l.ip6addr(t)then
return translate("Mandatory Input: No valid IPv6 address given!")
elseif not l.port(e[2])then
return translate("Mandatory Input: No valid Port given!")
else
return nil
end
end
e=c.split(a,":")
if not e[2]then
return translate("Mandatory Input: No Port given!")
end
if#e[1]>0 and not l.host(e[1])then
return translate("Mandatory Input: No valid IPv4 address or host given!")
elseif not l.port(e[2])then
return translate("Mandatory Input: No valid Port given!")
else
return nil
end
end
local e=""
local a=""
if type(t)=="table"then
local i
for i,t in ipairs(t)do
if t and#t>0 then
e=o(t)
if e then
a=t
break
end
end
end
else
e=o(t)
a=t
end
if e then
return nil,string.format(h(i.title_base,e.." - %s"),a)
end
return t
end
local a=e:taboption("access",DynamicList,"permit_access")
a.title=string.format(t,"ACLS","Permit access")
a.description=translate("Who can access what.")
..[[<br /><strong>]]
..translate("Please read Privoxy manual for details!")
..[[</strong>]]
a.rmempty=true
local a=e:taboption("access",DynamicList,"deny_access")
a.title=string.format(t,"ACLS","Deny Access")
a.description=translate("Who can access what.")
..[[<br /><strong>]]
..translate("Please read Privoxy manual for details!")
..[[</strong>]]
a.rmempty=true
local a=e:taboption("access",Value,"buffer_limit")
a.title_base="Buffer Limit"
a.title=string.format(t,"BUFFER-LIMIT",a.title_base)
a.description=translate("Maximum size (in KB) of the buffer for content filtering.")
..[[<br />]]
..translate("Value range 1 to 4096, no entry defaults to 4096")
a.default=4096
a.rmempty=true
function a.validate(t,a)
local e=tonumber(a)
if not e then
return nil,h(t.title_base,translate("Value is not a number"))
elseif e<1 or e>4096 then
return nil,h(t.title_base,translate("Value not between 1 and 4096"))
elseif e==t.default then
return""
end
return a
end
local a=e:taboption("access",Flag,"toggle")
a.title=string.format(t,"TOGGLE","Toggle Status")
a.description=translate("Enable/Disable filtering when Privoxy starts.")
..[[<br />]]
..translate("Disabled == Transparent Proxy Mode")
a.orientation="horizontal"
a.default="1"
a.rmempty=false
local a=e:taboption("access",Flag,"enable_remote_toggle")
a.title=string.format(t,"ENABLE-REMOTE-TOGGLE","Enable remote toggle")
a.description=translate("Whether or not the web-based toggle feature may be used.")
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("access",Flag,"enable_remote_http_toggle")
a.title=string.format(t,"ENABLE-REMOTE-HTTP-TOGGLE","Enable remote toggle via HTTP")
a.description=translate("Whether or not Privoxy recognizes special HTTP headers to change toggle state.")
..[[<br /><strong>]]
..translate("This option will be removed in future releases as it has been obsoleted by the more general header taggers.")
..[[</strong>]]
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("access",Flag,"enable_edit_actions")
a.title=string.format(t,"ENABLE-EDIT-ACTIONS","Enable action file editor")
a.description=translate("Whether or not the web-based actions file editor may be used.")
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("access",Flag,"enforce_blocks")
a.title=string.format(t,"ENFORCE-BLOCKS","Enforce page blocking")
a.description=translate("If enabled, Privoxy hides the 'go there anyway' link. "
.."The user obviously should not be able to bypass any blocks.")
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("forward",Flag,"enable_proxy_authentication_forwarding")
a.title=string.format(t,"ENABLE-PROXY-AUTHENTICATION-FORWARDING",
translate("Enable proxy authentication forwarding"))
a.description=translate("Whether or not proxy authentication through Privoxy should work.")
..[[<br /><strong>]]
..translate("Enabling this option is NOT recommended if there is no parent proxy that requires authentication!")
..[[</strong>]]
a.rmempty=true
local a=e:taboption("forward",DynamicList,"forward")
a.title=string.format(t,"FORWARD","Forward HTTP")
a.description=translate("To which parent HTTP proxy specific requests should be routed.")
..[[<br />]]
..translate("Syntax: target_pattern http_parent[:port]")
a.rmempty=true
local a=e:taboption("forward",DynamicList,"forward_socks4")
a.title=string.format(t,"SOCKS","Forward SOCKS 4")
a.description=translate("Through which SOCKS proxy (and optionally to which parent HTTP proxy) specific requests should be routed.")
..[[<br />]]
..translate("Syntax: target_pattern socks_proxy[:port] http_parent[:port]")
a.rmempty=true
local n=e:taboption("forward",DynamicList,"forward_socks4a")
n.title=string.format(t,"SOCKS","Forward SOCKS 4A")
n.description=a.description
n.rmempty=true
local n=e:taboption("forward",DynamicList,"forward_socks5")
n.title=string.format(t,"SOCKS","Forward SOCKS 5")
n.description=a.description
n.rmempty=true
local n=e:taboption("forward",DynamicList,"forward_socks5t")
n.title=string.format(t,"SOCKS","Forward SOCKS 5t")
n.description=a.description
n.rmempty=true
local a=e:taboption("misc",Flag,"accept_intercepted_requests")
a.title=string.format(t,"ACCEPT-INTERCEPTED-REQUESTS","Accept intercepted requests")
a.description=translate("Whether intercepted requests should be treated as valid.")
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("misc",Flag,"allow_cgi_request_crunching")
a.title=string.format(t,"ALLOW-CGI-REQUEST-CRUNCHING","Allow CGI request crunching")
a.description=translate("Whether requests to Privoxy's CGI pages can be blocked or redirected.")
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("misc",Flag,"split_large_forms")
a.title=string.format(t,"SPLIT-LARGE-FORMS","Split large forms")
a.description=translate("Whether the CGI interface should stay compatible with broken HTTP clients.")
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("misc",Value,"keep_alive_timeout")
a.title_base="Keep-alive timeout"
a.title=string.format(t,"KEEP-ALIVE-TIMEOUT",a.title_base)
a.description=translate("Number of seconds after which an open connection will no longer be reused.")
a.rmempty=true
function a.validate(e,t)
local a=tonumber(t)
if not a then
return nil,i(e.title_base,translate("Value is not a number"))
elseif a<1 then
return nil,i(e.title_base,translate("Value not greater 0 or empty"))
end
return t
end
local a=e:taboption("misc",Flag,"tolerate_pipelining")
a.title=string.format(t,"TOLERATE-PIPELINING","Tolerate pipelining")
a.description=translate("Whether or not pipelined requests should be served.")
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("misc",Value,"default_server_timeout")
a.title_base="Default server timeout"
a.title=string.format(t,"DEFAULT-SERVER-TIMEOUT",a.title_base)
a.description=translate("Assumed server-side keep-alive timeout (in seconds) if not specified by the server.")
a.rmempty=true
function a.validate(e,t)
local a=tonumber(t)
if not a then
return nil,i(e.title_base,translate("Value is not a number"))
elseif a<1 then
return nil,i(e.title_base,translate("Value not greater 0 or empty"))
end
return t
end
local a=e:taboption("misc",Flag,"connection_sharing")
a.title=string.format(t,"CONNECTION-SHARING","Connection sharing")
a.description=translate("Whether or not outgoing connections that have been kept alive should be shared between different incoming connections.")
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("misc",Value,"socket_timeout")
a.title_base="Socket timeout"
a.title=string.format(t,"SOCKET-TIMEOUT",a.title_base)
a.description=translate("Number of seconds after which a socket times out if no data is received.")
a.default=300
a.rmempty=true
function a.validate(t,a)
local e=tonumber(a)
if not e then
return nil,i(t.title_base,translate("Value is not a number"))
elseif e<1 then
return nil,i(t.title_base,translate("Value not greater 0 or empty"))
elseif e==t.default then
return""
end
return a
end
local a=e:taboption("misc",Value,"max_client_connections")
a.title_base="Max. client connections"
a.title=string.format(t,"MAX-CLIENT-CONNECTIONS",a.title_base)
a.description=translate("Maximum number of client connections that will be served.")
a.default=128
a.rmempty=true
function a.validate(e,a)
local t=tonumber(a)
if not t then
return nil,i(e.title_base,translate("Value is not a number"))
elseif t<1 then
return nil,i(e.title_base,translate("Value not greater 0 or empty"))
elseif t==e.default then
return""
end
return a
end
local a=e:taboption("misc",Flag,"handle_as_empty_doc_returns_ok")
a.title=string.format(t,"HANDLE-AS-EMPTY-DOC-RETURNS-OK","Handle as empty doc returns ok")
a.description=translate("The status code Privoxy returns for pages blocked with +handle-as-empty-document.")
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("misc",Flag,"enable_compression")
a.title=string.format(t,"ENABLE-COMPRESSION","Enable compression")
a.description=translate("Whether or not buffered content is compressed before delivery.")
a.orientation="horizontal"
a.rmempty=true
local a=e:taboption("misc",Value,"compression_level")
a.title_base="Compression level"
a.title=string.format(t,"COMPRESSION-LEVEL",a.title_base)
a.description=translate("The compression level that is passed to the zlib library when compressing buffered content.")
a.default=1
a.rmempty=true
function a.validate(t,a)
local e=tonumber(a)
if not e then
return nil,i(t.title_base,translate("Value is not a number"))
elseif e<0 or e>9 then
return nil,i(t.title_base,translate("Value not between 0 and 9"))
elseif e==t.default then
return""
end
return a
end
local a=e:taboption("misc",Value,"client_header_order")
a.title=string.format(t,"CLIENT-HEADER-ORDER","Client header order")
a.description=translate("The order in which client headers are sorted before forwarding them.")
..[[<br />]]
..translate("Syntax: Client header names delimited by spaces.")
a.rmempty=true
local a=e:taboption("debug",Flag,"single_threaded")
a.title=string.format(t,"SINGLE-THREADED","Single Threaded")
a.description=translate("Whether to run only one server thread.")
..[[<br /><strong>]]
..translate("This option is only there for debugging purposes. It will drastically reduce performance.")
..[[</strong>]]
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_1")
a.title=string.format(t,"DEBUG","Debug 1")
a.description=translate("Log the destination for each request Privoxy let through. See also 'Debug 1024'.")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_2")
a.title=string.format(t,"DEBUG","Debug 2")
a.description=translate("Show each connection status")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_4")
a.title=string.format(t,"DEBUG","Debug 4")
a.description=translate("Show I/O status")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_8")
a.title=string.format(t,"DEBUG","Debug 8")
a.description=translate("Show header parsing")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_16")
a.title=string.format(t,"DEBUG","Debug 16")
a.description=translate("Log all data written to the network")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_32")
a.title=string.format(t,"DEBUG","Debug 32")
a.description=translate("Debug force feature")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_64")
a.title=string.format(t,"DEBUG","Debug 64")
a.description=translate("Debug regular expression filters")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_128")
a.title=string.format(t,"DEBUG","Debug 128")
a.description=translate("Debug redirects")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_256")
a.title=string.format(t,"DEBUG","Debug 256")
a.description=translate("Debug GIF de-animation")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_512")
a.title=string.format(t,"DEBUG","Debug 512")
a.description=translate("Common Log Format")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_1024")
a.title=string.format(t,"DEBUG","Debug 1024")
a.description=translate("Log the destination for requests Privoxy didn't let through, and the reason why.")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_2048")
a.title=string.format(t,"DEBUG","Debug 2048")
a.description=translate("CGI user interface")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_4096")
a.title=string.format(t,"DEBUG","Debug 4096")
a.description=translate("Startup banner and warnings.")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_8192")
a.title=string.format(t,"DEBUG","Debug 8192")
a.description=translate("Non-fatal errors - *we highly recommended enabling this*")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_32768")
a.title=string.format(t,"DEBUG","Debug 32768")
a.description=translate("Log all data read from the network")
a.rmempty=true
local a=e:taboption("debug",Flag,"debug_65536")
a.title=string.format(t,"DEBUG","Debug 65536")
a.description=translate("Log the applying actions")
a.rmempty=true
local t=e:taboption("logview",DummyValue,"_logview")
t.template="privoxy/detail_logview"
t.inputtitle=translate("Read / Reread log file")
t.rows=50
function t.cfgvalue(t,a)
local e=t.map:get(e.section,"logdir").."/"..t.map:get(e.section,"logfile")
if o.access(e)then
return e.."\n"..translate("Please press [Read] button")
end
return e.."\n"..translate("File not found or empty")
end
return r
