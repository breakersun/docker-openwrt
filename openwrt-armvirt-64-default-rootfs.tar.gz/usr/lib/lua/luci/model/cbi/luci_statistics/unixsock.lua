m=Map("luci_statistics",
translate("Unixsock Plugin Configuration"),
translate(
"The unixsock plugin creates a unix socket which can be used "..
"to read collected data from a running collectd instance."
))
s=m:section(NamedSection,"collectd_unixsock","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
socketfile=s:option(Value,"SocketFile")
socketfile.default="/var/run/collect-query.socket"
socketfile:depends("enable",1)
socketgroup=s:option(Value,"SocketGroup")
socketgroup.default="nobody"
socketgroup.rmempty=true
socketgroup.optional=true
socketgroup:depends("enable",1)
socketperms=s:option(Value,"SocketPerms")
socketperms.default="0770"
socketperms.rmempty=true
socketperms.optional=true
socketperms:depends("enable",1)
return m
