m=Map("luci_statistics",
translate("Load Plugin Configuration"),
translate(
"The load plugin collects statistics about the general system load."
))
s=m:section(NamedSection,"collectd_load","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
return m
