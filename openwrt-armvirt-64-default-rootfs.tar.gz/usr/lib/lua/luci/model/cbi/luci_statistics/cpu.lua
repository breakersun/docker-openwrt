m=Map("luci_statistics",
translate("CPU Plugin Configuration"),
translate("The cpu plugin collects basic statistics about the processor usage."))
s=m:section(NamedSection,"collectd_cpu","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
return m
