m=Map("luci_statistics",
translate("DF Plugin Configuration"),
translate(
"The df plugin collects statistics about the disk space "..
"usage on different devices, mount points or filesystem types."
))
s=m:section(NamedSection,"collectd_df","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
devices=s:option(Value,"Devices",translate("Monitor devices"))
devices.default="/dev/mtdblock/4"
devices.optional=true
devices:depends("enable",1)
mountpoints=s:option(Value,"MountPoints",translate("Monitor mount points"))
mountpoints.default="/overlay"
mountpoints.optional=true
mountpoints:depends("enable",1)
fstypes=s:option(Value,"FSTypes",translate("Monitor filesystem types"))
fstypes.default="tmpfs"
fstypes.optional=true
fstypes:depends("enable",1)
ignoreselected=s:option(Flag,"IgnoreSelected",translate("Monitor all except specified"))
ignoreselected.default=0
ignoreselected:depends("enable",1)
return m
