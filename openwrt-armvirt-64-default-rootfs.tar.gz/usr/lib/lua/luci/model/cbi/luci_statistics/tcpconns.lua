m=Map("luci_statistics",
translate("TCPConns Plugin Configuration"),
translate(
"The tcpconns plugin collects informations about open tcp "..
"connections on selected ports."
))
s=m:section(NamedSection,"collectd_tcpconns","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
listeningports=s:option(Flag,"ListeningPorts",translate("Monitor all local listen ports"))
listeningports.default=1
listeningports:depends("enable",1)
localports=s:option(Value,"LocalPorts",translate("Monitor local ports"))
localports.optional=true
localports:depends("enable",1)
remoteports=s:option(Value,"RemotePorts",translate("Monitor remote ports"))
remoteports.optional=true
remoteports:depends("enable",1)
return m
