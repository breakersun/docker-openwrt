require"luci.sys"
local a,t,e
a=Map("luci_statistics",
translate("OpenVPN Plugin Configuration"),
translate("The OpenVPN plugin gathers information about the current vpn connection status."))
t=a:section(NamedSection,"collectd_openvpn","luci_statistics")
e=t:option(Flag,"enable",translate("Enable this plugin"))
e.default="0"
e=t:option(Flag,"CollectIndividualUsers",translate("Generate a separate graph for each logged user"))
e.default="0"
e.rmempty=true
e:depends("enable",1)
e=t:option(Flag,"CollectUserCount",translate("Aggregate number of connected users"))
e.default="0"
e.rmempty=true
e:depends("enable",1)
e=t:option(Flag,"CollectCompression",translate("Gather compression statistics"))
e.default="0"
e.rmempty=true
e:depends("enable",1)
e=t:option(Flag,"ImprovedNamingSchema",translate("Use improved naming schema"))
e.default="0"
e.rmempty=true
e:depends("enable",1)
e=t:option(DynamicList,"StatusFile",translate("OpenVPN status files"))
e.rmempty=true
e:depends("enable",1)
local t=nixio.fs.glob("/var/run/openvpn.*.status")
if t then
local a
for t in t do
e:value(t)
end
end
return a
