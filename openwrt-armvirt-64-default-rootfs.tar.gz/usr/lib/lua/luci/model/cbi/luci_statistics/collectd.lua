require("luci.sys")
m=Map("luci_statistics",
translate("Collectd Settings"),
translate(
"Collectd is a small daemon for collecting data from "..
"various sources through different plugins. On this page "..
"you can change general settings for the collectd daemon."
))
s=m:section(NamedSection,"collectd","luci_statistics")
hostname=s:option(Value,"Hostname",translate("Hostname"))
hostname.default=luci.sys.hostname()
hostname.optional=true
basedir=s:option(Value,"BaseDir",translate("Base Directory"))
basedir.default="/var/run/collectd"
include=s:option(Value,"Include",translate("Directory for sub-configurations"))
include.default="/etc/collectd/conf.d/*.conf"
plugindir=s:option(Value,"PluginDir",translate("Directory for collectd plugins"))
plugindir.default="/usr/lib/collectd/"
pidfile=s:option(Value,"PIDFile",translate("Used PID file"))
pidfile.default="/var/run/collectd.pid"
typesdb=s:option(Value,"TypesDB",translate("Datasets definition file"))
typesdb.default="/etc/collectd/types.db"
interval=s:option(Value,"Interval",translate("Data collection interval"),translate("Seconds"))
interval.default=60
interval.isnumber=true
readthreads=s:option(Value,"ReadThreads",translate("Number of threads for data collection"))
readthreads.default=5
readthreads.isnumber=true
fqdnlookup=s:option(Flag,"FQDNLookup",translate("Try to lookup fully qualified hostname"))
fqdnlookup.enabled="true"
fqdnlookup.disabled="false"
fqdnlookup.default="false"
fqdnlookup.optional=true
fqdnlookup:depends("Hostname","")
return m
