require("luci.sys")
m=Map("luci_statistics",
translate("DNS Plugin Configuration"),
translate(
"The dns plugin collects detailled statistics about dns "..
"related traffic on selected interfaces."
))
s=m:section(NamedSection,"collectd_dns","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
interfaces=s:option(MultiValue,"Interfaces",translate("Monitor interfaces"))
interfaces.widget="select"
interfaces.size=5
interfaces:depends("enable",1)
interfaces:value("any")
for t,e in pairs(luci.sys.net.devices())do
interfaces:value(e)
end
ignoresources=s:option(Value,"IgnoreSources",translate("Ignore source addresses"))
ignoresources.default="127.0.0.1"
ignoresources:depends("enable",1)
return m
