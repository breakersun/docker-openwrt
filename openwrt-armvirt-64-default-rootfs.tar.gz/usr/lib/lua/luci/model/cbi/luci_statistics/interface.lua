require("luci.sys")
m=Map("luci_statistics",
translate("Interface Plugin Configuration"),
translate(
"The interface plugin collects traffic statistics on "..
"selected interfaces."
))
s=m:section(NamedSection,"collectd_interface","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
interfaces=s:option(MultiValue,"Interfaces",translate("Monitor interfaces"))
interfaces.widget="select"
interfaces.size=5
interfaces:depends("enable",1)
for t,e in pairs(luci.sys.net.devices())do
interfaces:value(e)
end
ignoreselected=s:option(Flag,"IgnoreSelected",translate("Monitor all except specified"))
ignoreselected.default=0
ignoreselected:depends("enable",1)
return m
