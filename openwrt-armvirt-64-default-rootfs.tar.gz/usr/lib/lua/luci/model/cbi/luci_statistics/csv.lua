m=Map("luci_statistics",
translate("CSV Plugin Configuration"),
translate(
"The csv plugin stores collected data in csv file format "..
"for further processing by external programs."
))
s=m:section(NamedSection,"collectd_csv","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
datadir=s:option(Value,"DataDir",translate("Storage directory for the csv files"))
datadir.default="127.0.0.1"
datadir:depends("enable",1)
storerates=s:option(Flag,"StoreRates",translate("Store data values as rates instead of absolute values"))
storerates.default=0
storerates:depends("enable",1)
return m
