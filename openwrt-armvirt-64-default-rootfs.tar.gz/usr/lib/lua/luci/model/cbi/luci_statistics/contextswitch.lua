m=Map("luci_statistics",
translate("CPU Context Switches Plugin Configuration"),
translate("This plugin collects statistics about the processor context switches."))
s=m:section(NamedSection,"collectd_contextswitch","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
return m
