m=Map("luci_statistics",
translate("APCUPS Plugin Configuration"),
translate(
"The APCUPS plugin collects statistics about the APC UPS."
))
s=m:section(NamedSection,"collectd_apcups","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
host=s:option(Value,"Host",translate("Monitor host"),translate("Add multiple hosts separated by space."))
host.default="localhost"
host:depends("enable",1)
port=s:option(Value,"Port",translate("Port for apcupsd communication"))
port.isinteger=true
port.default=3551
port:depends("enable",1)
return m
