require("luci.sys")
local e=luci.sys.net.devices()
m=Map("luci_statistics",
translate("Netlink Plugin Configuration"),
translate(
"The netlink plugin collects extended informations like "..
"qdisc-, class- and filter-statistics for selected interfaces."
))
s=m:section(NamedSection,"collectd_netlink","luci_statistics")
enable=s:option(Flag,"enable",translate("Enable this plugin"))
enable.default=0
interfaces=s:option(MultiValue,"Interfaces",translate("Basic monitoring"))
interfaces.widget="select"
interfaces.optional=true
interfaces.size=#e+1
interfaces:depends("enable",1)
interfaces:value("")
for t,e in ipairs(e)do
interfaces:value(e)
end
verboseinterfaces=s:option(MultiValue,"VerboseInterfaces",translate("Verbose monitoring"))
verboseinterfaces.widget="select"
verboseinterfaces.optional=true
verboseinterfaces.size=#e+1
verboseinterfaces:depends("enable",1)
verboseinterfaces:value("")
for t,e in ipairs(e)do
verboseinterfaces:value(e)
end
qdiscs=s:option(MultiValue,"QDiscs",translate("Qdisc monitoring"))
qdiscs.widget="select"
qdiscs.optional=true
qdiscs.size=#e+1
qdiscs:depends("enable",1)
qdiscs:value("")
for t,e in ipairs(e)do
qdiscs:value(e)
end
classes=s:option(MultiValue,"Classes",translate("Shaping class monitoring"))
classes.widget="select"
classes.optional=true
classes.size=#e+1
classes:depends("enable",1)
classes:value("")
for t,e in ipairs(e)do
classes:value(e)
end
filters=s:option(MultiValue,"Filters",translate("Filter class monitoring"))
filters.widget="select"
filters.optional=true
filters.size=#e+1
filters:depends("enable",1)
filters:value("")
for t,e in ipairs(e)do
filters:value(e)
end
ignoreselected=s:option(Flag,"IgnoreSelected",translate("Monitor all except specified"))
ignoreselected.default=0
ignoreselected:depends("enable",1)
return m
