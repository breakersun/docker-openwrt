local a,t,e
a=Map("luci_statistics",
translate("Wireless iwinfo Plugin Configuration"),
translate("The iwinfo plugin collects statistics about wireless signal strength, noise and quality."))
t=a:section(NamedSection,"collectd_iwinfo","luci_statistics")
e=t:option(Flag,"enable",translate("Enable this plugin"))
e.default=0
e=t:option(Value,"Interfaces",translate("Monitor interfaces"),
translate("Leave unselected to automatically determine interfaces to monitor."))
e.template="cbi/network_ifacelist"
e.widget="checkbox"
e.nocreate=true
e:depends("enable",1)
e=t:option(Flag,"IgnoreSelected",translate("Monitor all except specified"))
e.default=0
e:depends("enable",1)
return a
