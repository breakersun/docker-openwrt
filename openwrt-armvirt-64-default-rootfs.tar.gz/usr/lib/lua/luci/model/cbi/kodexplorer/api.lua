local s=require"nixio.fs"
local a=require"luci.sys"
local c=require"luci.model.uci".cursor()
local t=require"luci.util"
local o=require"luci.i18n"
module("luci.model.cbi.kodexplorer.api",package.seeall)
local m="https://api.github.com/repos/kalcaddle/KodExplorer/releases/latest"
local n="https://github.com/kalcaddle/KodExplorer/archive/"
local u="/usr/bin/wget"
local l={"--no-check-certificate","--quiet","--timeout=10","--tries=2"}
local d="/usr/bin/curl"
local r=40
local function h(t,e)
e=e or 1
if t[e]~=nil then
return t[e],h(t,e+1)
end
end
local function i(h,r,a,o)
local i=require"os"
local e=require"nixio"
local s,n=e.pipe()
local t=e.fork()
if t>0 then
n:close()
if a or o then
local n=i.time()
while true do
if o and i.difftime(i.time(),n)>=o then
e.kill(t,e.const.SIGTERM)
return 1
end
if a then
local e=s:read(2048)
if e and#e>0 then
a(e)
end
end
local i,t,n=e.waitpid(t,"nohang")
if i and t=="exited"then
return n
end
if not a and o then
e.nanosleep(1)
end
end
else
local e,a,t=e.waitpid(t)
return e and a=="exited"and t
end
elseif t==0 then
e.dup(n,e.stdout)
s:close()
n:close()
e.exece(h,r,nil)
e.stdout:close()
i.exit(1)
end
end
local function e(a,e,o)
local i=table
local a=t.split(a,"[%.%-]",nil,true)
local o=t.split(o,"[%.%-]",nil,true)
local t=i.getn(a)
local i=i.getn(o)
if(t<i)then
t=i
end
for t=1,t,1 do
local a=a[t]or""
local t=o[t]or""
if e=="~="and(a~=t)then return true end
if(e=="<"or e=="<=")and(a<t)then return true end
if(e==">"or e==">=")and(a>t)then return true end
if(a~=t)then return false end
end
return not(e=="<"or e==">")
end
local function f(e)
local t=require"luci.jsonc"
local a={}
local e=luci.sys.exec(d.." -sL "..e)
if e==""then
return{}
end
return t.parse(e)or{}
end
function get_project_directory()
return c:get("kodexplorer","global","project_directory")or luci.sys.exec("echo -n `uci get kodexplorer.@global[0].project_directory`")
end
function to_check()
local e=f(m)
if e.tag_name==nil then
return{
code=1,
error=o.translate("Get remote version info failed.")
}
end
local a=e.tag_name
local t=e.html_url
n=n..e.tag_name..".tar.gz"
if not n then
return{
code=1,
version=a,
html_url=t,
error=o.translate("New version found, but failed to get new version download url.")
}
end
return{
code=0,
version=a,
url={
html=t,
download=n
}
}
end
function to_download(e)
if not e or e==""then
return{
code=1,
error=o.translate("Download url is required.")
}
end
a.call("/bin/rm -f /tmp/kodexplorer_download.*")
local t=t.trim(t.exec("mktemp -u -t kodexplorer_download.XXXXXX"))
local a=i(u,{
"-O",t,e,h(l)},nil,r)==0
if not a then
i("/bin/rm",{"-f",t})
return{
code=1,
error=o.translatef("File download failed or timed out: %s",e)
}
end
return{
code=0,
file=t
}
end
function to_extract(e)
if not e or e==""or not s.access(e)then
return{
code=1,
error=o.translate("File path required.")
}
end
a.call("/bin/rm -rf /tmp/kodexplorer_extract.*")
local o=t.trim(t.exec("mktemp -d -t kodexplorer_extract.XXXXXX"))
local a={}
i("/bin/tar",{"-C",o,"-zxvf",e},
function(e)a[#a+1]=e end)
local t=t.split(table.concat(a))
i("/bin/rm",{"-f",e})
return{
code=0,
file=o
}
end
function to_move(e)
if not e or e==""or not s.access(e)then
a.call("/bin/rm -rf /tmp/kodexplorer_extract.*")
return{
code=1,
error=o.translate("Client file is required.")
}
end
local t=get_project_directory()
a.call("mkdir -p "..t)
a.call("cp -R "..e.."/KodExplorer*/* "..t)
a.call("/bin/rm -rf /tmp/kodexplorer_extract.*")
return{code=0}
end
