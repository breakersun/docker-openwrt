#!/bin/sh

sleep 50 && /etc/init.d/unblockmusic restart
